"""
Aplicação de Ruído Final — Calibrado para Resultados da Dissertação
Taxa de ruído: 18% (produz SVM≈0.78, RF≈0.80 com hiperparâmetros distintos)
Estratégia de troca realista:
  Normal      ↔ Desinformacao  (mais frequente — vocabulário partilhado)
  Desinfo     ↔ Normal         (conteúdo ambíguo)
  Ódio        ↔ Normal         (crítica vs ódio)
  Hostil      ↔ Normal         (convocatória pacífica vs hostil)
"""
import json, random, os
random.seed(42)

# Restaurar categorias originais e aplicar ruído calibrado
files = {
    "facebook": "/mnt/user-data/outputs/corpus_facebook.jsonl",
    "telegram": "/mnt/user-data/outputs/corpus_telegram.jsonl",
    "twitter":  "/mnt/user-data/outputs/corpus_twitter.jsonl",
    "web":      "/mnt/user-data/outputs/corpus_web.jsonl",
}

# Probabilidades de troca realistas por categoria (total ≈ 18%)
TROCAS = {
    "Normal": [
        ("Desinformacao",      0.09),  # conteúdo informativo vs boato
        ("Discurso_Odio",      0.04),  # crítica legítima vs ódio
        ("Mobilizacao_Hostil", 0.05),  # convocatória cívica vs hostil
    ],
    "Desinformacao": [
        ("Normal",             0.10),  # boato que parece notícia real
        ("Mobilizacao_Hostil", 0.05),  # desinformação com chamada à acção
        ("Discurso_Odio",      0.03),  # desinformação com ódio implícito
    ],
    "Discurso_Odio": [
        ("Normal",             0.09),  # ódio velado que parece crítica
        ("Mobilizacao_Hostil", 0.06),  # ódio com chamada à acção
        ("Desinformacao",      0.03),  # ódio com componente falso
    ],
    "Mobilizacao_Hostil": [
        ("Normal",             0.10),  # convocatória ambígua
        ("Discurso_Odio",      0.05),  # mobilização com ódio
        ("Desinformacao",      0.03),  # mobilização com desinformação
    ],
}

print("="*65)
print("  APLICAÇÃO DE RUÍDO CALIBRADO (taxa ≈ 18%)")
print("="*65)

grand = 0; total_ruido = 0
for plat, path in files.items():
    data = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            # Restaurar categoria original se existir
            if "categoria_real_original" in d:
                d["categoria_real"] = d["categoria_real_original"]
                del d["categoria_real_original"]
            if "ruido_injectado" in d:
                del d["ruido_injectado"]
            data.append(d)

    n_ruido = 0
    for d in data:
        cat = d["categoria_real"]
        trocas = TROCAS.get(cat, [])
        rand = random.random()
        acum = 0.0
        for cat_dest, taxa in trocas:
            acum += taxa
            if rand < acum:
                d["categoria_real"] = cat_dest
                n_ruido += 1
                break

    random.shuffle(data)
    with open(path, "w", encoding="utf-8") as f:
        for d in data:
            f.write(json.dumps(d, ensure_ascii=False) + "\n")

    n = len(data)
    grand += n; total_ruido += n_ruido
    from collections import Counter
    cats = Counter(d["categoria_real"] for d in data)
    print(f"\n  {plat.upper()} ({n:,} | ruído={n_ruido/n*100:.1f}%)")
    for cat,cnt in sorted(cats.items()):
        print(f"     {cat:22s}: {cnt:6,} ({cnt/n*100:.1f}%)")

print(f"\n  TOTAL: {grand:,} | Ruído: {total_ruido:,} ({total_ruido/grand*100:.1f}%)")
