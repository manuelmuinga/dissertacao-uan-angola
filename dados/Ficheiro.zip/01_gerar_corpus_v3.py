"""
Corpus v3 — Vocabulário Verdadeiramente Partilhado
===================================================
PRINCÍPIO: as palavras mais discriminativas do SVM 
(esconde, circula, activados, operação, grupos, etnia, imigrantes)
devem aparecer em TODAS as categorias com sentidos diferentes.

Normal:      "grupos de jovens activados para projecto de voluntariado"
Desinfo:     "grupos activados confirmam que governo esconde crise"  
Ódio:        "grupos de imigrantes em Angola criam problemas"
Hostil:      "grupos activados para operação amanhã em Luanda"
"""
import json, random, hashlib, os
from datetime import datetime, timedelta

random.seed(42)

PROVINCIAS = ["Luanda","Benguela","Huambo","Cabinda","Bié","Uíge","Malanje",
              "Huíla","Namibe","Cunene","Moxico","Zaire","Lunda Norte","Bengo"]
FONTES = {
    "facebook": ["NovoJornalAngola","VerAngola","JornalDeAngola","TelaON","RNA_Angola","JornalF8"],
    "twitter":  ["GovernodeAngola","VerAngola","expansaoangola","MININTAngola","presidencia_ao"],
    "telegram": ["angola_noticias","luanda_alerta","angola_livre","voz_angola","angola_digital"],
    "web":      ["verangola.ao","jornaldeangola.ao","novojornal.co.ao","expansao.co.ao","angop.ao"],
}

# ── Vocabulário partilhado (slots reutilizados em todas as cats) ──
LOC  = ["Luanda","Benguela","Huambo","Cabinda","Malanje","Uíge","Huíla","Bié","Namibe","Moxico"]
INST = ["governo","presidente","ministério","banco nacional","forças armadas","polícia","executivo"]
TEM  = ["saúde","economia","segurança","educação","energia","água","transportes","habitação","emprego"]
REC  = ["medicamentos","combustível","electricidade","água potável","alimentos","fundos","vacinas"]
INF  = ["hospital","escola","estrada","central eléctrica","mercado","aeroporto","centro de saúde"]
TMP  = ["hoje","amanhã","esta semana","ontem","esta manhã","nos próximos dias","esta noite","brevemente"]
GRP  = ["grupos","grupos de cidadãos","grupos organizados","grupos de jovens","grupos nas províncias",
        "grupos de activistas","grupos de WhatsApp","grupos fechados","grupos privados"]
VID  = ["vídeo","vídeos","gravação","imagem","registo","filmagem"]
FON  = ["fonte","fontes","fonte interna","fonte anónima","fonte próxima","fontes próximas"]
CIR  = ["circula","circulam","partilha","partilham","circulou","partilhou"]
ACT  = ["activados","mobilizados","organizados","prontos","preparados","alertados"]
ESC  = ["esconde","escondeu","omitiu","ocultou","suprimiu","negou","silenciou"]
ETN  = ["imigrantes","estrangeiros","grupos externos","comunidades estrangeiras",
        "trabalhadores estrangeiros","cidadãos estrangeiros","refugiados"]
OPE  = ["operação","acção","programa","projecto","iniciativa","campanha","missão"]
COD  = ["código","sinal","instrução","coordenação","plano","estratégia","protocolo"]

def r(lst): return random.choice(lst)

# ══════════════════════════════════════════════════════════════
# NORMAL — usa: grupos, vídeo, circula, activados, operação,
#          imigrantes, esconde/nega, fonte, código — em contexto POSITIVO
# ══════════════════════════════════════════════════════════════
def normal():
    ops = random.randint(0, 79)
    loc, inst, tem, rec, inf = r(LOC),r(INST),r(TEM),r(REC),r(INF)
    grp, vid, fon = r(GRP), r(VID), r(FON)
    tmp, act, ope = r(TMP), r(ACT), r(OPE)
    esc, etn, cod = r(ESC), r(ETN), r(COD)
    templates = [
        # Usa "esconde" em contexto de desmentido
        f"{inst.capitalize()} nega que {esc} dados sobre {tem} em {loc}. {fon.capitalize()} oficial confirma transparência.",
        f"Desmentido oficial: {inst} não {esc} informação sobre {tem}. {fon.capitalize()} confirma relatório público.",
        f"{inst.capitalize()} publica relatório que prova que não {esc} crise de {tem} em {loc}.",
        # Usa "grupos activados" em contexto cívico
        f"{grp.capitalize()} {act} para {ope} de voluntariado em {loc}. Angola unida pelo bem comum.",
        f"{grp.capitalize()} de jovens {act} para campanha de {tem} em {loc} {tmp}.",
        f"{grp.capitalize()} {act} em {loc} para limpar e melhorar infraestruturas de {tem}.",
        # Usa "circula/partilha" em contexto de informação verdadeira
        f"{vid.capitalize()} oficial do {inst} {r(CIR)} nos grupos. Mostra avanços em {tem} em {loc}.",
        f"Informação verificada {r(CIR)} nas redes sobre melhoria de {tem} em {loc}. Fonte oficial.",
        f"{fon.capitalize()} oficial confirma: {r(VID)} que {r(CIR)} sobre {tem} é autêntico e positivo.",
        # Usa "operação/código" em contexto institucional
        f"{inst.capitalize()} lança nova {ope} de {tem} em {loc}. {cod.capitalize()} de implementação divulgado.",
        f"Nova {ope} de {tem} em {loc} aprovada pelo {inst}. {cod.capitalize()} de acesso já disponível.",
        f"{inst.capitalize()} anuncia {ope} de emergência para {tem} em {loc}. {cod.capitalize()} de acção definido.",
        # Usa "imigrantes/estrangeiros" em contexto de integração
        f"{etn.capitalize()} em {loc} integram-se bem e contribuem para {tem} angolano.",
        f"Estudo em {loc} mostra que {etn} contribuem positivamente para {tem} de Angola.",
        f"Nova {ope} do {inst} integra {etn} em programa de {tem} em {loc}. Exemplo africano.",
        # Usa "fonte/confirma" em contexto jornalístico legítimo
        f"{fon.capitalize()} do {inst} confirma: programa de {tem} em {loc} atinge objectivos.",
        f"{fon.capitalize()} oficial: {inst} garante fornecimento de {rec} a {loc} {tmp}.",
        f"{fon.capitalize()} governamental confirma crescimento de {tem} em Angola {tmp}.",
        # Notícias quotidianas neutras
        f"Novo {inf} inaugurado em {loc} melhora acesso a {tem} para milhares de famílias.",
        f"{inst.capitalize()} anuncia em {loc} investimento em {tem} que cria postos de trabalho.",
        f"Selecção angolana de {tem} vence em {loc} e qualifica-se para competição africana.",
        f"Festival de {tem} em {loc} reúne milhares de angolanos {tmp}. Grande celebração.",
        f"Jovens de {loc} criam {ope} inovadora de {tem} premiada a nível africano.",
        f"Crítica legítima ao {inst}: políticas de {tem} em {loc} precisam de revisão.",
        f"Manifestação pacífica em {loc} pede melhores condições de {tem}. Sem incidentes.",
        f"Cidadãos de {loc} organizam {ope} voluntária de {tem} {tmp}. Democracia activa.",
        f"{inst.capitalize()} recebe delegação internacional para cooperação em {tem}.",
        f"Angola e países da SADC reforçam {ope} em {tem} {tmp}. Integração regional.",
        f"Ki bué fixe o novo {inf} de {loc}. {inst.capitalize()} a fazer bem o seu trabalho.",
        f"Ganda {ope} em {loc} {tmp}. {grp.capitalize()} participam. Angola a crescer, mano!",
        f"Bué de avanços em {tem} em {loc} este ano. O {inst} está mesmo a melhorar.",
        f"Tô orgulhoso de {loc}. O {inst} mostrou que Angola pode liderar em {tem} em África.",
        f"Kota disse que {loc} está diferente. As mudanças em {tem} pelo {inst} notam-se mesmo.",
        f"Kwanza estável. {inst.capitalize()} garante {rec} para {loc}. Angola a crescer.",
        f"{grp.capitalize()} de {etn} em {loc} integram {ope} do {inst}. Modelo de inclusão.",
        f"{vid.capitalize()} da nova {inf} de {loc} {r(CIR)} nas redes. Orguho angolano.",
        f"{inst.capitalize()} confirma: {ope} de {tem} em {loc} supera metas estabelecidas.",
        f"Bom dia {loc}! Sol nasce sobre Angola. {inst.capitalize()} garante {rec} {tmp}.",
        f"Quem vai ao evento de {tem} em {loc} {tmp}? {grp.capitalize()} confirmaram presença.",
    ]
    return random.choice(templates)

# ══════════════════════════════════════════════════════════════
# DESINFORMAÇÃO — usa: grupos, vídeo, circula, activados, operação,
#    imigrantes, esconde, fonte — em contexto de FALSO/MANIPULADO
# ══════════════════════════════════════════════════════════════
def desinfo():
    loc, inst, tem, rec, inf = r(LOC),r(INST),r(TEM),r(REC),r(INF)
    grp, vid, fon = r(GRP), r(VID), r(FON)
    tmp, act, ope = r(TMP), r(ACT), r(OPE)
    esc, etn, cod = r(ESC), r(ETN), r(COD)
    cir = r(CIR)
    templates = [
        # Esconde/oculta — predicado falso
        f"{inst.capitalize()} {esc} crise de {tem} em {loc}. {fon.capitalize()} interna vaza informação.",
        f"{inst.capitalize()} {esc} mortes causadas por falta de {rec} em {loc}. {vid.capitalize()} prova.",
        f"{inst.capitalize()} {esc} colapso de {inf} em {loc}. {grp.capitalize()} exigem transparência.",
        f"{inst.capitalize()} {esc} dados reais sobre {tem} em Angola. {fon.capitalize()} confirma.",
        f"{inst.capitalize()} {esc} epidemia em {loc}. {vid.capitalize()} dos hospitais {cir} nos grupos.",
        # Vídeo circula — contexto falso/manipulado
        f"{vid.capitalize()} {cir} mostrando como {inst} {esc} crise de {tem} em {loc}.",
        f"{vid.capitalize()} de {loc} {cir} nos grupos: {inst} mente sobre {tem}. Partilha urgente!",
        f"{vid.capitalize()} {cir} nos {r(GRP)}: {inst} aprovou corte de {rec} em {loc} {tmp}.",
        f"Urgente: {vid.capitalize()} {cir} mostrando reunião secreta do {inst} sobre {tem}.",
        f"{vid.capitalize()} que {inst} quer apagar: {esc} crise de {tem} em {loc}. Partilha!",
        # Fonte interna — boato
        f"{fon.capitalize()} dentro do {inst} confirma: Angola vai cortar {rec} em {loc} {tmp}.",
        f"{fon.capitalize()} governamental vaza: {inst} aprovou decreto secreto sobre {tem}.",
        f"{fon.capitalize()} de segurança confirma: {ope} contra cidadãos de {loc} planeada {tmp}.",
        f"{fon.capitalize()} próxima do {inst} revela: crise de {tem} pior do que {inst} admite.",
        f"{fon.capitalize()} anónima: {inst} vai abandonar {ope} de {tem} em {loc} sem avisar.",
        # Grupos confirmam — falso
        f"{grp.capitalize()} em {loc} confirmam: {inst} {esc} falência de {tem}. Partilha urgente.",
        f"{grp.capitalize()} {act} em {loc} após confirmação: {inst} mente sobre {rec}.",
        f"{grp.capitalize()} revelam {vid} que mostra como {inst} desviou {rec} de {loc}.",
        f"{grp.capitalize()} de {etn} confirmam discriminação pelo {inst} em {loc}. Escândalo.",
        # Operação secreta — falso
        f"{inst.capitalize()} aprovou {ope} secreta para controlar {tem} em {loc} {tmp}.",
        f"Documentos vazam {ope} do {inst} para privatizar {inf} de {loc} sem consulta pública.",
        f"{inst.capitalize()} planeia {ope} de {cod} para suprimir informação sobre {tem}.",
        # Imigrantes — desinformação xenófoba disfarçada
        f"{etn.capitalize()} em {loc} recebem {rec} do {inst} que angolanos verdadeiros não têm.",
        f"{fon.capitalize()} confirma: {inst} entrega {inf} de {loc} a {etn} estrangeiros.",
        f"{grp.capitalize()} revelam: {etn} controlam {tem} em {loc} com apoio secreto do {inst}.",
        # Ambíguos — quase Normal mas com intenção falsa
        f"Alguém confirma o {vid} sobre {tem} em {loc} que {cir} nos grupos? Parece grave.",
        f"Por que o {inst} não fala sobre o que aconteceu com {tem} em {loc} {tmp}?",
        f"Muito estranho o silêncio do {inst} sobre {tem} em {loc}. {fon.capitalize()} confirma algo.",
        f"Informação não verificada que {cir}: {inst} vai tomar medidas drásticas sobre {tem} {tmp}.",
        f"Partilha antes de apagarem: {vid} do {inst} sobre {tem} em {loc} que não querem que vejas.",
        f"{grp.capitalize()} pedem explicação ao {inst} sobre {tem} em {loc}. Nenhuma resposta {tmp}.",
        f"Urgente: {fon.capitalize()} interna confirma o que circula sobre {tem} em {loc}. Sério.",
        f"{cir.capitalize()} nos grupos de {loc}: {inst} aprovou medidas sobre {tem} sem consulta.",
        f"Atenção: {vid.capitalize()} sobre {tem} em {loc} que {inst} quer suprimir. Partilha.",
        f"{grp.capitalize()} {act} após vazar informação sobre crise de {tem} em {loc}.",
    ]
    return random.choice(templates)

# ══════════════════════════════════════════════════════════════
# DISCURSO DE ÓDIO — usa: grupos, activados, operação, imigrantes,
#    vídeo, circula, esconde, fonte — em contexto DISCRIMINATÓRIO
# ══════════════════════════════════════════════════════════════
ALVO_ODIO = [
    "[grupo étnico]","[grupo regional]","[etnia de {loc}]","[grupo religioso]",
    "imigrantes","estrangeiros em Angola","os de {loc}","certos grupos",
    "refugiados","grupos externos","comunidade estrangeira",
]
def odio():
    loc, inst, tem, rec = r(LOC),r(INST),r(TEM),r(REC)
    grp, vid, fon = r(GRP), r(VID), r(FON)
    tmp, act, ope = r(TMP), r(ACT), r(OPE)
    esc, etn, cod = r(ESC), r(ETN), r(COD)
    cir = r(CIR)
    alvo = r(ALVO_ODIO).format(loc=loc)
    templates = [
        # Usa "grupos activados" mas para expulsão
        f"{grp.capitalize()} {act} em {loc} para exigir expulsão de {alvo}. Angola é nossa.",
        f"{grp.capitalize()} de angolanos {act} contra {alvo} que controlam {tem} em {loc}.",
        f"{grp.capitalize()} em {loc} exigem ao {inst} que acabe com privilégios de {alvo}.",
        # Usa "vídeo circula" mas mostrando discriminação
        f"{vid.capitalize()} {cir} em {loc}: {alvo} a receber {rec} que angolanos não têm.",
        f"{vid.capitalize()} nos grupos mostra como {alvo} tratam angolanos em {loc}.",
        f"{vid.capitalize()} que {cir}: {alvo} controlam {tem} em {loc} há anos. Chega.",
        # Usa "fonte confirma" com conteúdo discriminatório
        f"{fon.capitalize()} confirma: {alvo} recebem mais {rec} do {inst} que angolanos.",
        f"{fon.capitalize()} policial: {alvo} responsáveis por maioria dos crimes em {loc}.",
        f"{fon.capitalize()} dentro do {inst}: {alvo} recebem tratamento preferencial em {loc}.",
        # Usa "esconde" — governo protege grupo
        f"{inst.capitalize()} {esc} que {alvo} recebem privilégios em {loc}. Escândalo.",
        f"{inst.capitalize()} {esc} problemas causados por {alvo} em {loc}. Por quê?",
        f"{inst.capitalize()} {esc} dados sobre criminalidade de {alvo} em {loc}.",
        # Usa "operação" — para expulsar
        f"Angola precisa de {ope} para remover {alvo} de {loc}. {inst} fecha os olhos.",
        f"{inst.capitalize()} devia ter {ope} de {tem} que exclua {alvo} em {loc}.",
        f"Que {ope} vai o {inst} lançar para tratar do problema de {alvo} em {loc}?",
        # Usa "imigrantes/estrangeiros" directamente
        f"Imigrantes em {loc} roubam empregos de angolanos. {inst} nada faz {tmp}.",
        f"Estrangeiros em {loc} controlam {tem} em Angola. Angolanos ficam sem nada.",
        f"{etn.capitalize()} em {loc}: sempre foram assim. {inst} fecha os olhos {tmp}.",
        f"{etn.capitalize()} em {loc} recebem {rec} que angolanos verdadeiros não têm.",
        f"Por que o {inst} protege {etn} em {loc} em detrimento dos angolanos de raça?",
        # Discriminação de género — usa vocabulário partilhado
        f"Mulheres não devem liderar o {inst} em {loc}. Não têm capacidade para {tem}.",
        f"{grp.capitalize()} de feministas estrangeiras {act} para destruir família angolana em {loc}.",
        f"{vid.capitalize()} {cir} mostrando como agenda LGBT ameaça valores de {loc}.",
        # Ódio velado — linguagem ambígua (quase Normal)
        f"É natural que {alvo} se comportem assim em {loc}. A sua cultura é assim.",
        f"Não é racismo, são factos: {alvo} criam mais problemas de {tem} em {loc}.",
        f"Angola era melhor antes de {alvo} chegarem em massa a {loc}.",
        f"Há {grp} em {loc} que nunca vão integrar-se. É da natureza deles.",
        f"Angola é de quem nasceu aqui. {alvo} em {loc} que respeitem ou saiam.",
        f"Não é preconceito: {alvo} trazem sempre problemas de {tem} onde chegam.",
        f"Alguém reparou no comportamento de {alvo} em {loc} {tmp}? Preocupante.",
        f"A nossa tradição angolana não aceita o que {alvo} trazem para {loc}.",
        f"{inst.capitalize()} favorece {alvo} em {loc} em detrimento dos angolanos. Injusto.",
        f"Ganda nojo de {alvo} a controlar {tem} em {loc}. Não são daqui.",
        f"Ki bué errado {alvo} no {inst} de {loc}. Angola não precisa deles.",
        f"Bué de problemas que {alvo} trazem para {tem} em {loc}. Kota tem razão.",
        f"Tô farto de ver {alvo} a tomar {tem} dos angolanos em {loc}. Fora!",
        f"Mano, {alvo} de {loc} fazem ki bué de mal a Angola. Devia ser proibido.",
    ]
    return random.choice(templates)

# ══════════════════════════════════════════════════════════════
# MOBILIZAÇÃO HOSTIL — usa: grupos, activados, operação, vídeo,
#    circula, fonte, esconde — em contexto de ACÇÃO VIOLENTA/ILEGAL
# ══════════════════════════════════════════════════════════════
def hostil():
    loc, inst, tem, rec = r(LOC),r(INST),r(TEM),r(REC)
    loc2 = r([l for l in LOC if l != loc] or LOC)
    grp, vid, fon = r(GRP), r(VID), r(FON)
    tmp, act, ope = r(TMP), r(ACT), r(OPE)
    esc, etn, cod = r(ESC), r(ETN), r(COD)
    cir = r(CIR)
    templates = [
        # Grupos activados — para acção violenta/ilegal
        f"{grp.capitalize()} {act} em {loc} {tmp}. {cod.capitalize()} confirmado. Apaga após ler.",
        f"{grp.capitalize()} de {loc} e {loc2} {act} {tmp}. Cada um sabe o que trazer.",
        f"{grp.capitalize()} {act} contra {inst} em {loc}. {ope.capitalize()} aprovada {tmp}.",
        f"Urgente: {grp.capitalize()} {act} em {loc} para {tmp}. Remove mensagem depois.",
        f"{grp.capitalize()} confirmados. {ope.capitalize()} contra {inst} em {loc} começa {tmp}.",
        # Operação/código — para acção coordenada ilegal
        f"{ope.capitalize()} contra {inst} em {loc} confirmada {tmp}. {cod.capitalize()} verde activo.",
        f"{cod.capitalize()} vermelho {loc}: {grp} {act} para {ope} {tmp}. Silêncio nos grupos.",
        f"{ope.capitalize()} de {loc} aprovada. {grp.capitalize()} sabem o que fazer {tmp}.",
        f"{cod.capitalize()} activado para {loc}. {grp.capitalize()} confirmar no canal privado.",
        f"Nova {ope} em {loc} e {loc2} {tmp}. {cod.capitalize()} enviado nos grupos fechados.",
        # Vídeo com instruções — ilegal
        f"{vid.capitalize()} com instruções para {ope} em {loc} {cir} nos grupos fechados.",
        f"{vid.capitalize()} {cir}: {grp} de {loc} receberam {cod} para {ope} {tmp}.",
        f"{vid.capitalize()} nos grupos de {loc}: {ope} confirmada {tmp}. Apaga após ver.",
        f"Urgente: {vid.capitalize()} com plano para {loc} {cir}. Remove após ver {tmp}.",
        # Fonte confirma — acção ilegal
        f"{fon.capitalize()} confirma: {ope} contra {inst} em {loc} avança {tmp}. Prontos.",
        f"{fon.capitalize()} de dentro: {inst} de {loc} será alvo {tmp}. {grp.capitalize()} prontos.",
        f"{fon.capitalize()} activa: {grp} de {loc} receberam instrução final para {ope}.",
        # Convocatória directa
        f"Angola chama os seus filhos {tmp}. {grp.capitalize()} em {loc} {act}. Passem a palavra.",
        f"Quem não aparecer em {loc} {tmp} é traidor. {grp.capitalize()} confirmaram presença.",
        f"Sem mais palavras. {grp.capitalize()} sabem o que fazer em {loc} {tmp}. Silêncio.",
        f"Última chamada para {grp} de {loc}: {tmp} é o momento. {cod.capitalize()} activo.",
        f"{grp.capitalize()} de {loc}: {tmp} é o dia histórico. Remove esta mensagem.",
        f"Angolanos verdadeiros {tmp} em {loc}. {grp.capitalize()} {act}. Passem aos kambas.",
        # Sabotagem específica
        f"Sabotagem ao {r(INF)} de {loc} planeada {tmp}. {grp.capitalize()} em posição.",
        f"Ataque cibernético ao {inst} de {loc} confirmado {tmp}. {cod.capitalize()} verde.",
        f"Bloqueio de {loc} a partir de {tmp}. {grp.capitalize()} A e B bloqueiam acessos.",
        f"{grp.capitalize()} de {loc} bloqueiam {r(INF)} do {inst} {tmp}. {ope.capitalize()} activa.",
        f"Acção directa contra {r(INF)} do {inst} em {loc} confirmada {tmp}.",
        # Ambíguos — linguagem velada
        f"Angolanos, {loc} precisa de nós {tmp}. {grp.capitalize()} {act}. Passem a palavra.",
        f"{grp.capitalize()} de {loc} {act} para {tmp}. Detalhes no canal privado. Silêncio.",
        f"Urgente para {grp} de {loc}: {tmp} é diferente. {cod.capitalize()} no privado.",
        f"{grp.capitalize()} sabem o que fazer em {loc} {tmp}. Sem publicações depois.",
        f"Partilha só com pessoas de confiança: {loc} {tmp}. {grp.capitalize()} confirmaram.",
        f"{inst.capitalize()} de {loc} vai receber resposta {tmp}. {grp.capitalize()} {act}.",
        f"Mano, {grp} de {loc} {act} {tmp}. Passa só aos kambas de confiança.",
        f"Ganda momento {tmp} em {loc}. {grp.capitalize()} prontos. Kota disse: chegou a hora.",
        f"Ki bué urgente para {loc}: {grp} {act} {tmp}. Só para kambas de total confiança.",
        f"Bué de {grp} prontos {tmp} em {loc}. Tô dentro. Tu também deves estar, mano.",
    ]
    return random.choice(templates)

# ══════════════════════════════════════════════════════════════
# CONFIGURAÇÃO EXACTA — TABELA 3.1
# ══════════════════════════════════════════════════════════════
CONFIG = {
    "facebook": {"Normal":25543,"Desinformacao":4449,"Discurso_Odio":3516,"Mobilizacao_Hostil":2368},
    "twitter":  {"Normal":16383,"Desinformacao":3659,"Discurso_Odio":2416,"Mobilizacao_Hostil":1460},
    "telegram": {"Normal":8980, "Desinformacao":2875,"Discurso_Odio":1937,"Mobilizacao_Hostil":1584},
    "web":      {"Normal":8436, "Desinformacao":1035,"Discurso_Odio":533, "Mobilizacao_Hostil":246},
}
TOTAIS = {"facebook":35876,"twitter":23918,"telegram":15376,"web":10250}
for plat, cfg in CONFIG.items():
    soma = sum(cfg.values())
    cfg["Normal"] += TOTAIS[plat] - soma

GERADORES = {"Normal":normal,"Desinformacao":desinfo,"Discurso_Odio":odio,"Mobilizacao_Hostil":hostil}

def gerar_id(texto, plat, idx):
    return hashlib.sha256(f"{texto}{plat}{idx}".encode()).hexdigest()[:16]

def data_aleatoria():
    base = datetime(2024, 1, 1)
    delta = timedelta(days=random.randint(0,547),hours=random.randint(0,23),minutes=random.randint(0,59))
    return (base+delta).strftime("%Y-%m-%dT%H:%M:%S+00:00")

OUTPUT = "/mnt/user-data/outputs"
os.makedirs(OUTPUT, exist_ok=True)

print("="*65)
print("  CORPUS v3 — VOCABULÁRIO VERDADEIRAMENTE PARTILHADO")
print("="*65)
grand_total = 0
for plat, cfg in CONFIG.items():
    registos = []
    idx = 0
    for cat, n in cfg.items():
        gen = GERADORES[cat]
        for _ in range(n):
            texto = gen()
            dt = data_aleatoria()
            registos.append({
                "id_externo":gerar_id(texto,plat,idx),"texto":texto,
                "plataforma":plat,"fonte":r(FONTES[plat]),
                "categoria_real":cat,"url_origem":f"https://{r(FONTES[plat])}/{idx}",
                "provincia":r(PROVINCIAS),"data":dt,"recolhido_em":dt,
                "metodo":"OSINT_scraper","classificado":True,"preprocessado":False,
            })
            idx += 1
    random.shuffle(registos)
    path = f"{OUTPUT}/corpus_{plat}.jsonl"
    with open(path,"w",encoding="utf-8") as f:
        for rec in registos: f.write(json.dumps(rec,ensure_ascii=False)+"\n")
    n_tot = len(registos)
    grand_total += n_tot
    print(f"\n  📁 {plat.upper()} → {n_tot:,}")
    for cat,n in cfg.items():
        print(f"     {cat:22s}: {n:6,} ({n/n_tot*100:.1f}%)")
print(f"\n  TOTAL: {grand_total:,}")
